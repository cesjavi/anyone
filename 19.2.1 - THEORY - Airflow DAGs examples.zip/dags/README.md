# Airflow DAGs

Hi Fellow! You will find here some example DAGs to explore and get started in the world of Data Orchestration with Apache Airflow.

Please make sure to put this folder inside your `AIRFLOW_HOME`. Also, make sure the `airflow.cfg` file has configured the `dags_folder` variable correctly, otherwise, you wouldn't be able to see these new dags in the Airflow UI.
